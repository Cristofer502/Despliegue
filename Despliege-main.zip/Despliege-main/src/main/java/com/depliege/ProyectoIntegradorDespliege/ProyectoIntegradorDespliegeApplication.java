package com.depliege.ProyectoIntegradorDespliege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegradorDespliegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegradorDespliegeApplication.class, args);
	}

}
