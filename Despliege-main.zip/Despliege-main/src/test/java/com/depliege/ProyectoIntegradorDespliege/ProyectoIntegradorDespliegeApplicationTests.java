package com.depliege.ProyectoIntegradorDespliege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegradorDespliegeApplicationTests {

	@Test
	void contextLoads() {
	}

}
